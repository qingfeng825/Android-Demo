package com.example.lijinming.MyChart;

/**
 * Created by Administrator on 2016/3/30.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

/**
 * @author a1
 *
 */
public class WaveView extends SurfaceView implements Callback,Runnable{
    private Context       mContext;
    private SurfaceHolder surfaceHolder;
    private boolean flag = false;//线程标识
    private Bitmap  bitmapBackground;
    MyInternalStorage mMyInternalStorage;

    private float mSurfaceWidth,mSurfaceHeight;//屏幕宽高
    private int   mBitmapPos;

    private Canvas mCanvas;

    private Thread thread;

    public static Handler chartHandler ;

    Paint[] paints = new Paint[3];

//    private State state = State.LEFT;
//    private final int BITMAP_STEP = 1;//背景画布移动步伐

    public WaveView(Context context, AttributeSet attrs) {

        super(context, attrs);
        //setBackgroundColor(Color.GREEN);
        paints[0] = new Paint();
        paints[1] = new Paint();
        paints[2] = new Paint();
        paints[0].setColor(Color.RED);
        paints[1].setColor(Color.BLACK);
        paints[2].setColor(Color.BLUE);
        paints[0].setStrokeWidth(40);
        paints[1].setStrokeWidth(2);
        paints[2].setStrokeWidth(2);
        mMyInternalStorage = new  MyInternalStorage(getContext());

        mBitmapPos = 0;
        flag = true;
        this.mContext = context;
        /*setFocusable(true);
        setFocusableInTouchMode(true);*/
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);

    }
    @Override
    public void surfaceCreated(SurfaceHolder arg0) {
        mSurfaceWidth = getWidth();
        mSurfaceHeight = getHeight();
        Log.e("Width", String.valueOf(mSurfaceWidth));
        Log.e("Height", String.valueOf(mSurfaceHeight));
        thread = new Thread(this);
        thread.start();
//        mMyInternalStorage.get();
        /*GetDataThread getDataThread = new GetDataThread();
        new Thread(getDataThread).start();*/



    }
    int xpos = 0;
    int oldX = 0,x,y;
    float oldY1,oldY2,oldY3,y1,y2,y3;

    @Override
    public void run() {
        Looper.prepare();
        chartHandler = new Handler() {
            public void handleMessage(Message msg) {

//                y = msg.what;
//                Log.e("MSG", String.valueOf(y));

//                while (flag) {
                    synchronized (surfaceHolder) {
//                        Log.e("Xpos1", String.valueOf(xpos));
                        y = msg.what;
                        Log.e("MSG", String.valueOf(y));

                        if (xpos > mSurfaceWidth) {
                            xpos = 0;
                        }

//                        y1 =(float)((y+2300000)/10-5700);
                        y1 =(float)((y+100000)/50);
                        Log.e("WaveView", String.valueOf(y1));
                        Canvas canvas = surfaceHolder.lockCanvas(new Rect(xpos, 0,
                                xpos + 10/*(int)(mSurfaceWidth)*/, (int) (mSurfaceHeight)));
                        Log.e("Xpos", String.valueOf(xpos));
                        canvas.drawColor(Color.BLACK);
                        x = xpos;
                        canvas.drawLine(oldX, oldY1, x, y1, paints[0]);
                        oldX = x;
                        oldY1 = y1;
                        Log.e("Draw", String.valueOf(xpos));
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                    xpos += 1;
//                }
              /*  try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }
        };
        Looper.loop();

    }
    /*class GetDataThread implements Runnable {


        @Override
        public void run() {
            FileInputStream in = null;
            BufferedReader reader = null;
            File filename = new File(getExternalStorageBasePath() + "/" + "123.txt");
            try {
                in = new FileInputStream(filename);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            Log.e("filename", String.valueOf(filename));
            reader = new BufferedReader(new InputStreamReader(in));
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    Message msg = chartHandler.obtainMessage();
                    float y  = Float.parseFloat(line);
//                    int Y =(int) (y * 1000000);
                     int Y =(int) (y * -1000000);

                    msg.what = Y;
                    chartHandler.sendMessage(msg);
                    Log.e("TAG",String.valueOf(msg.what));
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        }
    }
        private boolean isExternalStorageWriteable() {
            String state = Environment.getExternalStorageState();
            if (Environment.MEDIA_MOUNTED.equals(state)) {
                return true;
            }
            return false;
        }

    *//**
     * 获取存储文件的根路径
     *
     * @return
     *//*
    private String getExternalStorageBasePath() {
        if (isExternalStorageWriteable()) {
            File file = new File(Environment.getExternalStorageDirectory() + "/MyDATA/");
            file.mkdirs();
            Log.e("getAbsolutePath", file.getAbsolutePath());
            return file.getAbsolutePath();
            } else {
                Toast.makeText(getContext(), "SD card不可读写", Toast.LENGTH_SHORT).show();
            }
            return null;
        }*/


    @Override
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder arg0) {
        flag = false;
    }


}
