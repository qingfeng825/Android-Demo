package com.example.lijinming.MyChart;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends Activity implements View.OnClickListener {
    private MyInternalStorage mMyInternalStorage;
    private Spinner mSpinner;
    private Button mButton;
    String str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMyInternalStorage = new MyInternalStorage(this);
        mButton = (Button)findViewById(R.id.start);
        mButton.setOnClickListener(this);


        mSpinner = (Spinner)findViewById(R.id.dataPlayBack);
        ArrayAdapter<String> fileArray = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,mMyInternalStorage.queryAllFile());
        mSpinner.setAdapter(fileArray);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 str = parent.getItemAtPosition(position).toString();
//                mMyInternalStorage.get(str);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onClick(View v) {
        int id =v.getId();
        switch (id){
            case R.id.start:
                mMyInternalStorage.get(str);
                break;
        }



    }
}

