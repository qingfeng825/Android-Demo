package com.example.lijinming.MyChart;

import android.content.Context;
import android.os.Environment;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2016/3/27.
 */
public class MyInternalStorage {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");
    Date curDate = new Date(System.currentTimeMillis());//获取当前时间
    String Str = formatter.format(curDate);//获取系统时间
    //需要保存当前调用对象的Context
    private Context context;

    public MyInternalStorage(Context context) {
        this.context = context;
    }
    /**
     * 存储数据到Sd card
     * @param inputText 为要保存的数据
     * */

    /**
     * 从Sdcard中读取数据
     *
     * @return 读取的数据以String格式返回
     */
    public void get(final String pathname) {

//        final String path = pathname;
        new Thread(new Runnable() {
            @Override
            public void run() {
                FileInputStream in = null;
                BufferedReader reader = null;
                File filename = new File(pathname);
            /*getExternalStorageBasePath() + "/" + "123.txt"*/
                try {
                    in = new FileInputStream(filename);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                Log.e("filename", String.valueOf(filename));
                reader = new BufferedReader(new InputStreamReader(in));
                String line;
                try {
                    while ((line = reader.readLine()) != null) {
                        Message msg = WaveView.chartHandler.obtainMessage();

//                        String cut = line.substring(3);
//                        Log.e("CUT", cut);
                        float fy = Float.parseFloat(line);
                        int iY =(int) (fy * 1000000);
                        String sY = String.valueOf(iY);
                        String cut = sY.substring(2);

                        Log.e("CUT", cut);

                        int iy = Integer.parseInt(cut);



                        int Y = iy * -1;

                        msg.what = Y;
                        WaveView.chartHandler.sendMessage(msg);
                        Log.e("TAG", String.valueOf(msg.what));
                        try {
                            Thread.sleep(2);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }

            }
        }).start();

        /*GetDataThread getDataThread = new GetDataThread();
        new Thread(getDataThread).start();*/
        //        StringBuilder content = new StringBuilder();
       /* try {
            File filename = new File(getExternalStorageBasePath()+"/"+"123.txt");
            in = new FileInputStream(filename);
            Log.e("filename", String.valueOf(filename));
            reader = new BufferedReader(new InputStreamReader(in));
            String line;
            GetDataThread getDataThread = new GetDataThread();
            new Thread(getDataThread).start();
            while ((line = reader.readLine()) != null) {
                Log.e("TAG",line);

//                content.append(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }*/
    }

   /* class GetDataThread implements Runnable {

        @Override
        public void run() {
            FileInputStream in = null;
            BufferedReader reader = null;
            File filename = new File();
            *//*getExternalStorageBasePath() + "/" + "123.txt"*//*
            try {
                in = new FileInputStream(filename);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            Log.e("filename", String.valueOf(filename));
            reader = new BufferedReader(new InputStreamReader(in));
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    Message msg = WaveView.chartHandler.obtainMessage();
                    float y = Float.parseFloat(line);
                    //                    int Y =(int) (y * 1000000);
                    int Y = (int) (y * -1000000);

                    msg.what = Y;
                    WaveView.chartHandler.sendMessage(msg);
                    Log.e("TAG", String.valueOf(msg.what));
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        }
    }*/


        /**
         * 以追加的方式在指定文件的末尾添加内容
         *
         * @param content 追加的内容
         */
        public void append(String content) throws IOException {
            String file = getExternalStorageBasePath() + "/" + Str + ".txt";
            FileOutputStream fos = new FileOutputStream(file, true);
            fos.write(content.getBytes());
            fos.close();
        }

        /**
         * 删除文件
         *
         * @param filename 文件名
         * @return 是否成功
         */
        public boolean delete(String filename) {
            File file = new File(filename);
            file.delete();
            return true;
        }

        /**
         * 获取SD card指定存储路径下的所有文件名
         * @return 文件名数组
         */
        public List<String> queryAllFile() {
            File file = new File(Environment.getExternalStorageDirectory()+"/MyDATA/");
            File [] files  =  file.listFiles();
            List <String> pathname = new ArrayList<>();
            for (File f:files){
                pathname.add(f.toString());
            }
            return pathname;
        }

        private boolean isExternalStorageWriteable() {
            String state = Environment.getExternalStorageState();
            if (Environment.MEDIA_MOUNTED.equals(state)) {
                return true;
            }
            return false;
        }

        /**
         * 获取存储文件的根路径
         *
         * @return
         */
        private String getExternalStorageBasePath() {
            if (isExternalStorageWriteable()) {
                File file = new File(Environment.getExternalStorageDirectory() + "/MyDATA/");
                file.mkdirs();
                Log.e("getAbsolutePath", file.getAbsolutePath());
                return file.getAbsolutePath();
            } else {
                Toast.makeText(context, "SD card不可读写", Toast.LENGTH_SHORT).show();
            }
            return null;
        }

}
