package com.example.lijinming.viewpagerandfragment;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class RecommendFragment extends android.support.v4.app.Fragment {
    private TextView recommend;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // View v = inflater.inflate(R.layout.recommend_frag, container, false);
        View view = inflater.inflate(R.layout.recommend_frag, container, false);
        recommend = (TextView)view.findViewById(R.id.recommend);
        return view;
       // return v;

    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

}
