package com.example.lijinming.viewpagerandfragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
public class MyPagerFragment extends android.support.v4.app.Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private ViewPager mPager;
    private ArrayList<android.support.v4.app.Fragment> fragmentsList;
    private ImageView ivBottomLine;
    private TextView tvTabNew, tvTabHot, monthHot, dayHot;

    private int currIndex = 0;
    private int bottomLineWidth;
    private int offset = 0;
    private int position_one;
    private int position_two;
    private int position_three;
    android.support.v4.app.Fragment home1;
    android.support.v4.app.Fragment home2;
    android.support.v4.app.Fragment home3;
    android.support.v4.app.Fragment home4;


    public MyPagerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.view_pager, container, false);
        ViewPager vp = (ViewPager) view.findViewById(R.id.viewPaper);
        InitWidth(view);
        InitTextView(view);
        InitViewPager(view);
        return view;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
    private void InitTextView(View parentView) {
        tvTabNew = (TextView) parentView.findViewById(R.id.tv_tab_1);
        tvTabHot = (TextView) parentView.findViewById(R.id.tv_tab_2);
        monthHot = (TextView) parentView.findViewById(R.id.tv_tab_3);
        dayHot = (TextView) parentView.findViewById(R.id.tv_tab_4);
        tvTabNew.setOnClickListener(new MyOnClickListener(0));
        tvTabHot.setOnClickListener(new MyOnClickListener(1));
        monthHot.setOnClickListener(new MyOnClickListener(2));
        dayHot.setOnClickListener(new MyOnClickListener(3));

    }

    private void InitViewPager(View parentView) {
        mPager = (ViewPager) parentView.findViewById(R.id.viewPaper);
        fragmentsList = new ArrayList<android.support.v4.app.Fragment>();

        home1 = new RecommendFragment();
        home2 = new CollectFragment();
        home3 = new MonthHotFragment();
        home4 = new DayHotFragment();

        fragmentsList.add(home1);
        fragmentsList.add(home2);
        fragmentsList.add(home3);
        fragmentsList.add(home4);


        mPager.setAdapter(new MyPagerAdapter(getChildFragmentManager(), fragmentsList));
        mPager.setOnPageChangeListener(new MyOnPageChangeListener());
        mPager.setCurrentItem(0);

    }

    private void InitWidth(View parentView) {
        ivBottomLine = (ImageView) parentView.findViewById(R.id.iv_bottom_line);
        bottomLineWidth = ivBottomLine.getLayoutParams().width;
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;
        offset = (int) ((screenW / 4.0 - bottomLineWidth) / 2);
        //int avg = (int) (screenW / num);
        position_one = (int) (screenW / 4.0);
        position_two = position_one * 2;
        position_three = position_one * 3;
    }

    public class MyOnClickListener implements View.OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        @Override
        public void onClick(View v) {
            mPager.setCurrentItem(index);
        }
    }

    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageSelected(int arg0) {
            Animation animation = null;
            switch (arg0) {
                case 0:
                    if (currIndex == 1) {
                        animation = new TranslateAnimation(position_one, 0, 0, 0);
                        //tvTabHot.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 2) {
                        animation = new TranslateAnimation(position_two, 0, 0, 0);
                        // monthHot.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 3) {
                        animation = new TranslateAnimation(position_three, 0, 0, 0);
                        // dayHot.setTextColor(resources.getColor(R.color.lightwhite));
                    }
                    //tvTabNew.setTextColor(resources.getColor(R.color.white));
                    break;

                case 1:
                    if (currIndex == 0) {
                        animation = new TranslateAnimation(0, position_one, 0, 0);
                        // tvTabNew.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 2) {
                        animation = new TranslateAnimation(position_two, position_one, 0, 0);
                        // monthHot.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 3) {
                        animation = new TranslateAnimation(position_three, position_one, 0, 0);
                        // dayHot.setTextColor(resources.getColor(R.color.lightwhite));
                    }
                    //tvTabHot.setTextColor(resources.getColor(R.color.white));
                    break;
                case 2:
                    if (currIndex == 0) {
                        animation = new TranslateAnimation(0, position_two, 0, 0);
                        // tvTabNew.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 1) {
                        animation = new TranslateAnimation(position_one, position_two, 0, 0);
                        // tvTabHot.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 3) {
                        animation = new TranslateAnimation(position_three, position_two, 0, 0);
                        //                            dayHot.setTextColor(resources.getColor(R.color.lightwhite));
                    }
                    // monthHot.setTextColor(resources.getColor(R.color.white));
                    break;
                case 3:
                    if (currIndex == 0) {
                        animation = new TranslateAnimation(0, position_three, 0, 0);
                        //tvTabNew.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 1) {
                        animation = new TranslateAnimation(position_one, position_three, 0, 0);
                        //  tvTabHot.setTextColor(resources.getColor(R.color.lightwhite));
                    } else if (currIndex == 2) {
                        animation = new TranslateAnimation(position_two, position_three, 0, 0);
                        //                            monthHot.setTextColor(resources.getColor(R.color.lightwhite));
                    }
                    //dayHot.setTextColor(resources.getColor(R.color.white));
                    break;
            }
            currIndex = arg0;
            animation.setFillAfter(true);
            animation.setDuration(300);
            ivBottomLine.startAnimation(animation);
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }
    }
}
