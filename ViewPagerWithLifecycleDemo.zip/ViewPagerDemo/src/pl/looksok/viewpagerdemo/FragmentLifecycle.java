package pl.looksok.viewpagerdemo;

public interface FragmentLifecycle {

	public void onPauseFragment();
	public void onResumeFragment();
	
}
